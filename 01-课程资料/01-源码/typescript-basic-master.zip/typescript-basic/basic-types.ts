let isDone: boolean = false

let age: number = 10

let firstName: string = 'viking'
let message: string = `Hello, ${firstName}`

let u: undefined = undefined
let n:null = null

let num: number = undefined

let notSure: any = 4
notSure = 'maybe a string'
notSure = true

notSure.myName
notSure.getName()