let arrOfNumbers: number[] = [1,2,3]
arrOfNumbers.push(3)

function test() {
  console.log(arguments)
}

let user: [string, number] = ['viking', 20]